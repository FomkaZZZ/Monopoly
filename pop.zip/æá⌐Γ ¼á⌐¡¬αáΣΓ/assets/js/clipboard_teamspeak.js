function copy(){
    navigator.clipboard.writeText('ts.onecraft.it')
    swal({
    title: 'IP COPIATO',
    text: 'BUON DIVERTIMENTO',
    icon: 'success',
    timer: 2000,
    buttons: false,
})
}