function copy(){
    navigator.clipboard.writeText('mc.1poly.fun')
    swal({
    title: 'IP скопирован',
    text: 'Приятной игры',
    icon: 'success',
    timer: 3000,
    buttons: false,
})
}
